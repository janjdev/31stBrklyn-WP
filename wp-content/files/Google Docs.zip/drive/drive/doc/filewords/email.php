<?php
$emailku = 'gboyega1987@gmail.com';
?>