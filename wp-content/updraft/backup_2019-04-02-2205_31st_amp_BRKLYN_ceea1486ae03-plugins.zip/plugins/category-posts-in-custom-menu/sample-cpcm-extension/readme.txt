=== Sample CPCM Extension ===
Contributors: anaid
Tags: menu, category, post tag, tag, posts, dynamic, automatic, custom, taxonomy, custom taxonomy, extension
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 0.1

This plugin is a sample that shows how to extend the plugin Category Posts in Custom Menu with your own fields.

== Description ==

This plugin is not intended to be released in the Wordpress plugin archive. 
Activate the plugin and you should see an extra field "Exclude Posts by Post ID", as discussed at https://wordpress.org/support/topic/exclude-single-posts?replies=5
Also, if you use wildcard "%hello_world" in your post title, it will be replaced with "Hello, World!"