﻿          
          @@@@@@           @@@@@@
        @@@@@@@@@@       @@@@@@@@@@
      @@@@@@@@@@@@@@   @@@@@@@@@@@@@@
    @@@@@@@@@@@@@@@@@ @@@@@@@@@@@@@@@@@
   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@	Thank you for downloading Gravit!
    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@		you can acces our documentation at: http://support.tryand.net
     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@		If you have any questions, problems or issues get in touch with us:
	@@@@@@@@@@@@@@@@@@@@@@@@@@@		contact@tryand.net	
          @@@@@@@@@@@@@@@@@@@@@@@		Or send us a support ticket at: http://support.tryand.net/support-tickets/
            @@@@@@@@@@@@@@@@@@@
              @@@@@@@@@@@@@@@			If you enjoye Gravit make sure to check out our other themes at www.tryand.net
                @@@@@@@@@@@
                  @@@@@@@
                    @@@
                     @				
        


